// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XSIMP_FUN_H
#define XSIMP_FUN_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xsimp_fun_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Ctrl_BaseAddress;
} XSimp_fun_Config;
#endif

typedef struct {
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XSimp_fun;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XSimp_fun_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XSimp_fun_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XSimp_fun_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XSimp_fun_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XSimp_fun_Initialize(XSimp_fun *InstancePtr, UINTPTR BaseAddress);
XSimp_fun_Config* XSimp_fun_LookupConfig(UINTPTR BaseAddress);
#else
int XSimp_fun_Initialize(XSimp_fun *InstancePtr, u16 DeviceId);
XSimp_fun_Config* XSimp_fun_LookupConfig(u16 DeviceId);
#endif
int XSimp_fun_CfgInitialize(XSimp_fun *InstancePtr, XSimp_fun_Config *ConfigPtr);
#else
int XSimp_fun_Initialize(XSimp_fun *InstancePtr, const char* InstanceName);
int XSimp_fun_Release(XSimp_fun *InstancePtr);
#endif

void XSimp_fun_Start(XSimp_fun *InstancePtr);
u32 XSimp_fun_IsDone(XSimp_fun *InstancePtr);
u32 XSimp_fun_IsIdle(XSimp_fun *InstancePtr);
u32 XSimp_fun_IsReady(XSimp_fun *InstancePtr);
void XSimp_fun_EnableAutoRestart(XSimp_fun *InstancePtr);
void XSimp_fun_DisableAutoRestart(XSimp_fun *InstancePtr);

void XSimp_fun_Set_x(XSimp_fun *InstancePtr, u32 Data);
u32 XSimp_fun_Get_x(XSimp_fun *InstancePtr);
void XSimp_fun_Set_w(XSimp_fun *InstancePtr, u32 Data);
u32 XSimp_fun_Get_w(XSimp_fun *InstancePtr);
void XSimp_fun_Set_b(XSimp_fun *InstancePtr, u32 Data);
u32 XSimp_fun_Get_b(XSimp_fun *InstancePtr);
u32 XSimp_fun_Get_y(XSimp_fun *InstancePtr);
u32 XSimp_fun_Get_y_vld(XSimp_fun *InstancePtr);

void XSimp_fun_InterruptGlobalEnable(XSimp_fun *InstancePtr);
void XSimp_fun_InterruptGlobalDisable(XSimp_fun *InstancePtr);
void XSimp_fun_InterruptEnable(XSimp_fun *InstancePtr, u32 Mask);
void XSimp_fun_InterruptDisable(XSimp_fun *InstancePtr, u32 Mask);
void XSimp_fun_InterruptClear(XSimp_fun *InstancePtr, u32 Mask);
u32 XSimp_fun_InterruptGetEnabled(XSimp_fun *InstancePtr);
u32 XSimp_fun_InterruptGetStatus(XSimp_fun *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
