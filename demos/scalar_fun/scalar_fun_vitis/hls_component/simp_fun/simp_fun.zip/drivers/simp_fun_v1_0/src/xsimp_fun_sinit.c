// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xsimp_fun.h"

extern XSimp_fun_Config XSimp_fun_ConfigTable[];

#ifdef SDT
XSimp_fun_Config *XSimp_fun_LookupConfig(UINTPTR BaseAddress) {
	XSimp_fun_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XSimp_fun_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XSimp_fun_ConfigTable[Index].Ctrl_BaseAddress == BaseAddress) {
			ConfigPtr = &XSimp_fun_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSimp_fun_Initialize(XSimp_fun *InstancePtr, UINTPTR BaseAddress) {
	XSimp_fun_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSimp_fun_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSimp_fun_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XSimp_fun_Config *XSimp_fun_LookupConfig(u16 DeviceId) {
	XSimp_fun_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSIMP_FUN_NUM_INSTANCES; Index++) {
		if (XSimp_fun_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XSimp_fun_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSimp_fun_Initialize(XSimp_fun *InstancePtr, u16 DeviceId) {
	XSimp_fun_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSimp_fun_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSimp_fun_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

