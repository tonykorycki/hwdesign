// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// CTRL
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of x
//        bit 31~0 - x[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of w
//        bit 31~0 - w[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of b
//        bit 31~0 - b[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of y
//        bit 31~0 - y[31:0] (Read)
// 0x2c : Control signal of y
//        bit 0  - y_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XSIMP_FUN_CTRL_ADDR_AP_CTRL 0x00
#define XSIMP_FUN_CTRL_ADDR_GIE     0x04
#define XSIMP_FUN_CTRL_ADDR_IER     0x08
#define XSIMP_FUN_CTRL_ADDR_ISR     0x0c
#define XSIMP_FUN_CTRL_ADDR_X_DATA  0x10
#define XSIMP_FUN_CTRL_BITS_X_DATA  32
#define XSIMP_FUN_CTRL_ADDR_W_DATA  0x18
#define XSIMP_FUN_CTRL_BITS_W_DATA  32
#define XSIMP_FUN_CTRL_ADDR_B_DATA  0x20
#define XSIMP_FUN_CTRL_BITS_B_DATA  32
#define XSIMP_FUN_CTRL_ADDR_Y_DATA  0x28
#define XSIMP_FUN_CTRL_BITS_Y_DATA  32
#define XSIMP_FUN_CTRL_ADDR_Y_CTRL  0x2c

