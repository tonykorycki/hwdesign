// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xsimp_fun.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSimp_fun_CfgInitialize(XSimp_fun *InstancePtr, XSimp_fun_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSimp_fun_Start(XSimp_fun *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSimp_fun_ReadReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_AP_CTRL) & 0x80;
    XSimp_fun_WriteReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSimp_fun_IsDone(XSimp_fun *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSimp_fun_ReadReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSimp_fun_IsIdle(XSimp_fun *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSimp_fun_ReadReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSimp_fun_IsReady(XSimp_fun *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSimp_fun_ReadReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSimp_fun_EnableAutoRestart(XSimp_fun *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSimp_fun_WriteReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_AP_CTRL, 0x80);
}

void XSimp_fun_DisableAutoRestart(XSimp_fun *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSimp_fun_WriteReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_AP_CTRL, 0);
}

void XSimp_fun_Set_x(XSimp_fun *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSimp_fun_WriteReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_X_DATA, Data);
}

u32 XSimp_fun_Get_x(XSimp_fun *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSimp_fun_ReadReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_X_DATA);
    return Data;
}

void XSimp_fun_Set_w(XSimp_fun *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSimp_fun_WriteReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_W_DATA, Data);
}

u32 XSimp_fun_Get_w(XSimp_fun *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSimp_fun_ReadReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_W_DATA);
    return Data;
}

void XSimp_fun_Set_b(XSimp_fun *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSimp_fun_WriteReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_B_DATA, Data);
}

u32 XSimp_fun_Get_b(XSimp_fun *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSimp_fun_ReadReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_B_DATA);
    return Data;
}

u32 XSimp_fun_Get_y(XSimp_fun *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSimp_fun_ReadReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_Y_DATA);
    return Data;
}

u32 XSimp_fun_Get_y_vld(XSimp_fun *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSimp_fun_ReadReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_Y_CTRL);
    return Data & 0x1;
}

void XSimp_fun_InterruptGlobalEnable(XSimp_fun *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSimp_fun_WriteReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_GIE, 1);
}

void XSimp_fun_InterruptGlobalDisable(XSimp_fun *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSimp_fun_WriteReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_GIE, 0);
}

void XSimp_fun_InterruptEnable(XSimp_fun *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSimp_fun_ReadReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_IER);
    XSimp_fun_WriteReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_IER, Register | Mask);
}

void XSimp_fun_InterruptDisable(XSimp_fun *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSimp_fun_ReadReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_IER);
    XSimp_fun_WriteReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_IER, Register & (~Mask));
}

void XSimp_fun_InterruptClear(XSimp_fun *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSimp_fun_WriteReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_ISR, Mask);
}

u32 XSimp_fun_InterruptGetEnabled(XSimp_fun *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSimp_fun_ReadReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_IER);
}

u32 XSimp_fun_InterruptGetStatus(XSimp_fun *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSimp_fun_ReadReg(InstancePtr->Ctrl_BaseAddress, XSIMP_FUN_CTRL_ADDR_ISR);
}

